#!/tools/iccad/bin/python3.4

# Name: Abdulqayyum

import argparse #It easy to write user-friendly command-line interfaces.
import re #RegEx can be used to check if a string contains the specified search pattern.
from collections import namedtuple # It supports a type of container like dictionaries called “namedtuple()” present in the module, “collections".



class P4Info: # Helix Server client class. Handles connection and interaction with the Helix Server. There is one instance of each connection.
    """Represents p4.log file"""
    Lock = namedtuple("Lock",
        ("user", "command", "wait_read", "wait_write", "held_read",
            "held_write"))
    r_list=[]
    def __init__(self, p4_log):
        """Initialize by the entire parsing p4.log

        p4_log: path to p4.log
        """
        self.__db_locks = self.__get_db_locks(p4_log) # Calling___get___db_locks

    def __get_db_locks(self, p4_log): # used to define a function, defining p4.log file
        """Return list of Lock

        p4_log: path to p4.log
        """
        with open("p4.log", "r") as s: # exception handling and to create an alias.
            log_data=s.readlines()
        # print(log_data) 

        #TODO
        # 1. Call __get_info_blocks(p4_log) to parse p4_log
        #    into list of info blocks

        self.__get_info_blocks(log_data) 
        # 2. For each info block, call __str2dblock(info_block)
        #    to convert str to Lock namedtuple
        pass

    def __get_info_blocks(self, p4_log): # to parse p4_log
        """Return str block of Perforce server info p4_log: path to p4.log"""
        key = False       
        infoData = []
        logData = []
        for data in p4_log: 
            if data.find("Perforce server info") == 0: 
                if key == True:
                    logData.append(infoData) #Adding server info without "Perforce server info" word
                    infoData = []
                key = True
                continue
            if key == True:
                if data.find("Perforce server error") == 0:
                    key = False
                    continue
                infoData.append(re.sub(r'\s', ' ', data)) #Removed additional whitespaces and stored
            
        mainLog = []
        for data in logData:
            mainLog.append([''.join(data[0:])])
        self.__str2dblock(mainLog)

    def __str2dblock(self, info_block):
        """Convert str to Lock namedtuple
        
        info_block: p4 info block
        """
        #TODO
        pass

    def get_max_wait_read(self):
        """Return str of highest wait_read"""
        #TODO
        pass

    def get_max_wait_write(self):
        """Return str of highest wait_write"""
        #TODO

    def get_max_held_read(self):
        """Return str with highest held_read"""
        #TODO


    def get_max_held_write(self):
        """Return str with highest held_write"""
        #TODO


def main():
    parser = argparse.ArgumentParser(
            description="P4 log parser for Python Interview",
            formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("p4log", type=str, help="p4.log file to parse")
    args = parser.parse_args()
    p4info = P4Info(args.p4log)

    # p4 information

   print("Maximum wait read :" + "Result tuple here" + "\n")
    
    print("Maximum wait write :" + "Result tuple here" + "\n")
    
    print("Maximum held read :" + "Result tuple here" + "\n")
    
    print("Maximum held write :" + "Result tuple here" + "\n")


if __name__ == "__main__": main()

